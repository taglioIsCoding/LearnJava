package gasforlife.model;

public enum BillingFrequency {
 MONTHLY, ANNUAL;
}
